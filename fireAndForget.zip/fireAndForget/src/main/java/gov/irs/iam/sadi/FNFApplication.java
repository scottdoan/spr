package gov.irs.iam.sadi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FNFApplication {

	public static void main(String[] args) {
		SpringApplication.run(FNFApplication.class, args);
	}

}
