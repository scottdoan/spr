package gov.irs.iam.sadi.controller;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
public class FnfService {

	@Async
	void fireAndForget(String message) throws InterruptedException {
		Thread.sleep(100);
	//	System.out.println("FnfService processed message: " + message);
	}
}
