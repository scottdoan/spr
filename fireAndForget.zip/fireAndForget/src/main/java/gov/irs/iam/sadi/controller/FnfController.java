package gov.irs.iam.sadi.controller;

import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.RejectedExecutionException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FnfController {

	@Autowired
	FnfService fnfService;

	// TODO: this should be a POST. using Get for POC, but change to post
	// eventually.
	@GetMapping("/logaccess")
	public @ResponseBody ResponseEntity<String> get(HttpServletRequest req) throws InterruptedException {
		Instant start = Instant.now();
		
		int success = 0;
		int failed = 0;
		String qs = req.getQueryString();
		for (int i = 1; i <= 2000; i++) {
			try {
				if(i%500==0) {
					Thread.sleep(1000);
					System.out.println("********** pause at 200 TPS ****************");
				}
				fnfService.fireAndForget(i + "::" + qs);
				//System.out.println("success for " + i);
				success++;
			} catch (RejectedExecutionException e) {
				//System.out.println("***********************caught RejectedExecutionException: " + i + "************************");
				//e.printStackTrace();
				System.out.println("failed FnFService: " + i);
				failed++;
			}
		}
		Instant finish = Instant.now();
		long timeElapsed = Duration.between(start, finish).toMillis()/1000;
		System.out.println("time elapsed: " + timeElapsed + " seconds.");
		System.out.println("succeeded: " + success);
		System.out.println("failed: " + failed);
		return new ResponseEntity<String>("Success: " + qs, HttpStatus.OK);
	}

}
